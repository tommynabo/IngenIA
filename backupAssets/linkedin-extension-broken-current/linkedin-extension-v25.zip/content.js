// ========================================
// IngenIA V25 - COMPLETE REBUILD
// Robust insertion into LinkedIn's dynamic UI
// ========================================

console.log("🚀 IngenIA V25 REBUILT - STARTING");

// ========== CONFIGURATION ==========
const CONFIG = {
    POLLING_INTERVAL: 1000,
    REFRESH_CHECK_INTERVAL: 3000,
    DEBUG: true  // Enabled for better diagnostics
};

// ========== STATE ==========
const state = {
    processedPosts: new WeakSet(),
    processedComments: new WeakSet(),
    processedButtons: new Set()
};

// ========== MAIN INITIALIZATION ==========
document.addEventListener('DOMContentLoaded', init);
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}

function init() {
    showStartBanner();
    
    // Start polling
    setInterval(scanAndInjectPosts, CONFIG.POLLING_INTERVAL);
    setInterval(scanAndInjectCommentReplies, CONFIG.POLLING_INTERVAL);
    setInterval(checkConnection, CONFIG.REFRESH_CHECK_INTERVAL);
    
    // Initial scan
    setTimeout(() => {
        scanAndInjectPosts();
        scanAndInjectCommentReplies();
    }, 500);
}

function showStartBanner() {
    const banner = document.createElement('div');
    banner.style.cssText = `
        position:fixed;
        top:70px;
        right:20px;
        background:#0a66c2;
        color:white;
        padding:10px 16px;
        border-radius:20px;
        font-weight:bold;
        z-index:999999;
        font-size:13px;
        box-shadow:0 4px 12px rgba(0,0,0,0.3);
    `;
    banner.innerText = "✅ IngenIA V25 Activo";
    document.body.appendChild(banner);
    setTimeout(() => banner.remove(), 4000);
}

// ========== POSTS INJECTION ==========
function scanAndInjectPosts() {
    // Strategy: Look for all article containers or update containers
    const allArticles = document.querySelectorAll('article, .feed-shared-update-v2, [data-feed-item-id]');
    log(`Found ${allArticles.length} potential posts`);
    
    let injectedCount = 0;
    allArticles.forEach(article => {
        if (state.processedPosts.has(article)) return;
        if (!isElementVisible(article)) return;
        
        // Find the action bar (where like/comment/share buttons are)
        const actionBar = findActionBar(article);
        
        if (actionBar && !actionBar.querySelector('[data-ingenia-post-buttons]')) {
            injectPostButtons(article, actionBar);
            state.processedPosts.add(article);
            injectedCount++;
        }
    });
    
    if (injectedCount > 0) {
        log(`✅ Inyectados ${injectedCount} posts`);
    }
}

function findActionBar(article) {
    // LinkedIn's action bar typically contains buttons with specific aria-labels or classes
    // Look for elements with multiple buttons (like, comment, share, etc)
    
    // Method 1: Look for elements with role="toolbar"
    const toolbar = article.querySelector('[role="toolbar"]');
    if (toolbar && hasActionButtons(toolbar)) {
        log('✓ Action bar found via [role="toolbar"]');
        return toolbar;
    }
    
    // Method 2: Look for divs that contain action buttons
    const divs = article.querySelectorAll('div');
    for (let div of divs) {
        const buttons = div.querySelectorAll('button');
        if (buttons.length >= 2 && hasActionButtons(div)) {
            log('✓ Action bar found via divs with buttons');
            return div;
        }
    }
    
    // Method 3: Look for common LinkedIn class patterns
    const patterns = [
        '.social-action-bar',
        '.feed-shared-social-action-bar',
        '[data-test-id*="action"]',
        '[class*="social-action"]'
    ];
    
    for (let pattern of patterns) {
        const el = article.querySelector(pattern);
        if (el && hasActionButtons(el)) {
            log(`✓ Action bar found via ${pattern}`);
            return el;
        }
    }
    
    log('✗ Action bar not found in article');
    return null;
}

function hasActionButtons(element) {
    const buttons = element.querySelectorAll('button');
    if (buttons.length < 2) return false;
    
    // Check if buttons have aria-labels typical of LinkedIn actions
    for (let btn of buttons) {
        const label = btn.getAttribute('aria-label') || '';
        const text = btn.innerText.toLowerCase();
        if (label.includes('like') || label.includes('comment') || 
            text.includes('like') || text.includes('comment') ||
            label.includes('reacciona') || label.includes('comentar')) {
            return true;
        }
    }
    
    return false;
}

function injectPostButtons(article, actionBar) {
    const container = document.createElement('div');
    container.setAttribute('data-ingenia-post-buttons', 'true');
    container.style.cssText = `
        display: inline-flex;
        gap: 8px;
        align-items: center;
        margin-left: auto;
        padding: 0 8px;
    `;
    
    // Button: Comentar
    const commentBtn = createIconButton('💬', 'Comentar', () => {
        handlePostAction(article, 'comment', commentBtn);
    });
    
    // Button: Resumir
    const summaryBtn = createIconButton('📝', 'Resumir', () => {
        handlePostAction(article, 'summarize', summaryBtn);
    });
    
    container.appendChild(commentBtn);
    container.appendChild(summaryBtn);
    
    actionBar.appendChild(container);
    
    log(`✅ Botones inyectados en post`);
}

// ========== COMMENT REPLIES INJECTION ==========
function scanAndInjectCommentReplies() {
    // LinkedIn comments are nested articles or have specific comment classes
    const comments = document.querySelectorAll(
        'article article, ' +  // Nested articles (comments)
        '.comments-comment-item, ' +
        '[data-urn*="comment"], ' +
        '[data-test-id*="comment"]'
    );
    
    log(`Found ${comments.length} potential comments`);
    let injectedCount = 0;
    
    comments.forEach(comment => {
        if (state.processedComments.has(comment)) return;
        if (!isElementVisible(comment)) return;
        
        // Find the action buttons area for this comment
        // Try multiple strategies
        let actionArea = comment.querySelector('[role="toolbar"]');
        
        if (!actionArea) {
            actionArea = comment.querySelector('[class*="action"]');
        }
        
        if (!actionArea) {
            // Last resort: find the area with buttons
            const allDivs = comment.querySelectorAll('div');
            for (let div of allDivs) {
                const buttons = div.querySelectorAll('button');
                if (buttons.length >= 2) {
                    actionArea = div;
                    break;
                }
            }
        }
        
        if (actionArea && !actionArea.querySelector('[data-ingenia-reply-btn]')) {
            injectReplyButton(comment, actionArea);
            state.processedComments.add(comment);
            injectedCount++;
        }
    });
    
    if (injectedCount > 0) {
        log(`✅ Inyectados ${injectedCount} botones de respuesta`);
    }
}

function injectReplyButton(comment, actionArea) {
    const replyBtn = createIconButton('💭', 'Responder IA', () => {
        handleCommentAction(comment, 'reply', replyBtn);
    });
    
    replyBtn.setAttribute('data-ingenia-reply-btn', 'true');
    replyBtn.title = 'Generar respuesta con IA';
    
    actionArea.appendChild(replyBtn);
    
    log(`✅ Botón de respuesta inyectado en comentario`);
}

// ========== ACTION HANDLERS ==========
async function handlePostAction(article, type, button) {
    const licenseKey = await getLicenseKey();
    if (!licenseKey) return;
    
    const { text, author } = extractPostContent(article);
    if (!text) {
        showToast('❌ No se encontró texto');
        return;
    }
    
    await generateAndShowResult(text, author, type, button);
}

async function handleCommentAction(comment, type, button) {
    const licenseKey = await getLicenseKey();
    if (!licenseKey) return;
    
    const { text, author } = extractCommentContent(comment);
    if (!text) {
        showToast('❌ No se encontró comentario');
        return;
    }
    
    await generateAndShowResult(text, author, type, button);
}

async function generateAndShowResult(text, author, type, button) {
    const originalHTML = button.innerHTML;
    button.innerHTML = '⏳';
    button.disabled = true;
    
    try {
        // Validate text
        if (!text || text.length === 0) {
            showToast('❌ No se encontró contenido para procesar');
            button.innerHTML = originalHTML;
            button.disabled = false;
            return;
        }
        
        const licenseKey = await getLicenseKey();
        if (!licenseKey) {
            button.innerHTML = originalHTML;
            button.disabled = false;
            return;
        }
        
        let prompt = '';
        if (type === 'summarize') {
            prompt = `Resume brevemente esto en español (máx 3 puntos). Autor: ${author}\n\n${text}`;
        } else if (type === 'comment') {
            prompt = `Genera un comentario profesional y amable en español para este post de ${author}:\n\n${text}`;
        } else if (type === 'reply') {
            prompt = `Responde a este comentario en español de forma breve y profesional (máx 2 frases). Autor: ${author}\n\n${text}`;
        }
        
        log(`Enviando ${type} a API...`);
        
        const response = await sendMessageToBackground({
            action: 'generate_comment',
            licenseKey: licenseKey,
            prompt: prompt
        });
        
        if (response.success && response.result) {
            log(`✅ Respuesta recibida (${response.result.length} caracteres)`);
            showResultModal(type, response.result);
        } else {
            const errorMsg = response.error || 'Error desconocido en la API';
            log(`❌ Error: ${errorMsg}`);
            showToast('❌ ' + errorMsg);
        }
    } catch (error) {
        log(`❌ Exception: ${error.message}`);
        showToast('❌ Error: ' + error.message);
    } finally {
        button.innerHTML = originalHTML;
        button.disabled = false;
    }
}

// ========== CONTENT EXTRACTION ==========
function extractPostContent(article) {
    try {
        // Clone to avoid modifying DOM
        const clone = article.cloneNode(true);
        
        // Remove buttons and metadata noise
        clone.querySelectorAll('button, [data-ingenia-post-buttons], script, style, [class*="popup"], [class*="modal"]').forEach(el => el.remove());
        
        // Try multiple selectors for post text
        const selectors = [
            '.feed-shared-text-view',
            '.feed-shared-update-v2__description',
            '[class*="description"]',
            'p'
        ];
        
        let text = '';
        for (let selector of selectors) {
            const el = clone.querySelector(selector);
            if (el) {
                text = el.innerText.trim();
                if (text.length > 50) break;
            }
        }
        
        // Fallback: get all text
        if (text.length < 50) {
            text = clone.innerText.trim();
        }
        
        // Clean up excessive whitespace
        text = text.replace(/\n\s*\n/g, '\n').trim();
        
        // Extract author
        let author = extractAuthor(article);
        
        if (!text || text.length === 0) {
            log('⚠️ No text found in post');
            return { text: null, author };
        }
        
        return {
            text: text.substring(0, 2000),
            author: author
        };
    } catch (e) {
        log('❌ Error extracting post content:', e.message);
        return { text: null, author: 'unknown' };
    }
}

function extractCommentContent(comment) {
    try {
        const clone = comment.cloneNode(true);
        clone.querySelectorAll('button, [data-ingenia-reply-btn], script, style').forEach(el => el.remove());
        
        // Try finding comment text
        const selectors = [
            '[data-urn*="comment"] p',
            '.comments-comment-item__main-content',
            '[class*="comment"] p',
            'p'
        ];
        
        let text = '';
        for (let selector of selectors) {
            const el = clone.querySelector(selector);
            if (el) {
                text = el.innerText.trim();
                if (text.length > 20) break;
            }
        }
        
        if (text.length < 20) {
            text = clone.innerText.trim();
        }
        
        // Clean up whitespace
        text = text.replace(/\n\s*\n/g, '\n').trim();
        
        let author = extractAuthor(comment);
        
        if (!text || text.length === 0) {
            log('⚠️ No text found in comment');
            return { text: null, author };
        }
        
        return {
            text: text.substring(0, 2000),
            author: author
        };
    } catch (e) {
        log('❌ Error extracting comment content:', e.message);
        return { text: null, author: 'unknown' };
    }
}

function extractAuthor(element) {
    // Try multiple selectors for author name
    const selectors = [
        '.update-components-actor__name',
        '[dir="ltr"] strong',
        '.comments-post-meta__name-text',
        '[class*="name"] strong',
        'strong'
    ];
    
    for (let selector of selectors) {
        const el = element.querySelector(selector);
        if (el) {
            let name = el.innerText.split('\n')[0].trim();
            if (name && name.length > 2 && name.length < 100) {
                return name;
            }
        }
    }
    
    return 'el autor';
}

// ========== MODAL & UI ==========
function showResultModal(type, result) {
    const overlay = document.createElement('div');
    overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.6);
        z-index: 10001;
        display: flex;
        justify-content: center;
        align-items: center;
        backdrop-filter: blur(4px);
    `;
    
    const modal = document.createElement('div');
    modal.style.cssText = `
        background: white;
        border-radius: 12px;
        padding: 24px;
        max-width: 600px;
        width: 90%;
        max-height: 70vh;
        overflow-y: auto;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        font-family: -apple-system, system-ui, sans-serif;
    `;
    
    const title = document.createElement('h2');
    title.innerText = type === 'summarize' ? '📝 Resumen' : (type === 'comment' ? '💬 Comentario' : '💭 Respuesta');
    title.style.cssText = 'margin-top: 0; margin-bottom: 16px; color: #0a66c2;';
    
    const content = document.createElement('div');
    content.innerText = result;
    content.style.cssText = `
        background: #f3f3f3;
        padding: 16px;
        border-radius: 8px;
        margin-bottom: 16px;
        white-space: pre-wrap;
        word-wrap: break-word;
        color: #333;
        line-height: 1.5;
    `;
    
    const footer = document.createElement('div');
    footer.style.cssText = 'display: flex; gap: 8px; justify-content: flex-end;';
    
    const copyBtn = document.createElement('button');
    copyBtn.innerText = '📋 Copiar';
    copyBtn.style.cssText = `
        padding: 10px 16px;
        background: #f0f0f0;
        border: 1px solid #ccc;
        border-radius: 6px;
        cursor: pointer;
        font-weight: 600;
    `;
    copyBtn.onclick = () => {
        navigator.clipboard.writeText(result);
        showToast('✅ Copiado');
    };
    
    const insertBtn = document.createElement('button');
    insertBtn.innerText = '✅ Insertar';
    insertBtn.style.cssText = `
        padding: 10px 16px;
        background: #0a66c2;
        color: white;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-weight: 600;
    `;
    insertBtn.onclick = () => {
        insertResultIntoEditor(result);
        overlay.remove();
        showToast('✅ Insertado');
    };
    
    const closeBtn = document.createElement('button');
    closeBtn.innerText = '✕ Cerrar';
    closeBtn.style.cssText = `
        padding: 10px 16px;
        background: transparent;
        border: 1px solid #ccc;
        border-radius: 6px;
        cursor: pointer;
        font-weight: 600;
    `;
    closeBtn.onclick = () => overlay.remove();
    
    footer.append(copyBtn, insertBtn, closeBtn);
    modal.append(title, content, footer);
    overlay.appendChild(modal);
    
    overlay.onclick = (e) => {
        if (e.target === overlay) overlay.remove();
    };
    
    document.body.appendChild(overlay);
}

function showToast(message) {
    const toast = document.createElement('div');
    toast.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: #333;
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        z-index: 10002;
        font-weight: 600;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    `;
    toast.innerText = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

function insertResultIntoEditor(text) {
    // Find the active editor (usually the one being typed in)
    const editor = document.querySelector('[contenteditable="true"]') || 
                   document.querySelector('.ql-editor');
    
    if (editor) {
        editor.focus();
        document.execCommand('insertText', false, text);
        editor.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
        navigator.clipboard.writeText(text);
        showToast('📋 Copiado al portapapeles (editor no encontrado)');
    }
}

// ========== UTILITIES ==========
function createIconButton(icon, title, onClick) {
    const btn = document.createElement('button');
    btn.style.cssText = `
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: transparent;
        border: 1px solid transparent;
        padding: 6px 12px;
        border-radius: 20px;
        cursor: pointer;
        color: #666;
        font-weight: 600;
        font-size: 13px;
        transition: all 0.2s;
        gap: 4px;
    `;
    
    btn.innerHTML = icon;
    btn.title = title;
    
    btn.onmouseover = () => {
        btn.style.background = '#f0f0f0';
        btn.style.color = '#0a66c2';
    };
    
    btn.onmouseout = () => {
        btn.style.background = 'transparent';
        btn.style.color = '#666';
    };
    
    btn.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        onClick();
    };
    
    return btn;
}

function isElementVisible(element) {
    if (!element || element.offsetParent === null) return false;
    const rect = element.getBoundingClientRect();
    return rect.top < window.innerHeight && rect.bottom > 0;
}

async function getLicenseKey() {
    try {
        const store = await chrome.storage.sync.get(['licenseKey']);
        if (!store.licenseKey) {
            showToast('⚠️ Configura tu clave de licencia');
            return null;
        }
        return store.licenseKey;
    } catch (e) {
        showToast('❌ Error accediendo a la licencia');
        return null;
    }
}

function sendMessageToBackground(payload) {
    return new Promise((resolve, reject) => {
        try {
            chrome.runtime.sendMessage(payload, (response) => {
                if (chrome.runtime.lastError) {
                    reject(chrome.runtime.lastError);
                } else {
                    resolve(response);
                }
            });
        } catch (e) {
            reject(e);
        }
    });
}

function checkConnection() {
    try {
        chrome.runtime.sendMessage({ action: 'ping' }, (response) => {
            if (chrome.runtime.lastError) {
                log('⚠️ Conexión perdida - recarga la página');
            }
        });
    } catch (e) {
        log('⚠️ Extension context invalidated');
    }
}

function log(msg) {
    if (CONFIG.DEBUG) console.log('[IngenIA]', msg);
}
